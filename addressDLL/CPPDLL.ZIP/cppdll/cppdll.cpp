#include "cppdll.h"

//prevent function name from being mangled
extern "C" 
int cube(int num) {
	return num * num * num;
}